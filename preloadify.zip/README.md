## Preloadify

Preloadify uses preloading to to make the web faster. It preloads links on mouse hover and makes them instantly available when you click them. This way, you can navigate faster through the web.

## Credits:
- This is a updated and maintained version of the extension developed by Simon Frey: https://github.com/simonfrey/faster-pageload-web-extensions
- Instant.page script by Alexandre Dieulot (https://dieulot.fr) - licensed under the MIT license (https://opensource.org/licenses/MIT)
